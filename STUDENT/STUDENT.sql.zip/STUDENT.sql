-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 30, 2020 at 11:42 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `student`
--

-- --------------------------------------------------------

--
-- Table structure for table `stud_details`
--

CREATE TABLE `stud_details` (
  `id` int(11) NOT NULL auto_increment,
  `sname` varchar(265) NOT NULL,
  `sdob` varchar(265) NOT NULL,
  `sgender` varchar(265) NOT NULL,
  `scontact` varchar(265) NOT NULL,
  `semail` varchar(265) NOT NULL,
  `saddress` varchar(265) NOT NULL,
  `spin` varchar(265) NOT NULL,
  `state` varchar(265) NOT NULL,
  `city` varchar(265) NOT NULL,
  `country` varchar(265) NOT NULL,
  `class` varchar(265) NOT NULL,
  `subject` varchar(265) NOT NULL,
  `marks` varchar(265) default NULL,
  `sscmarks` varchar(265) default NULL,
  `username` varchar(265) NOT NULL,
  `password` varchar(265) NOT NULL,
  `otp` int(6) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `stud_details`
--

INSERT INTO `stud_details` (`id`, `sname`, `sdob`, `sgender`, `scontact`, `semail`, `saddress`, `spin`, `state`, `city`, `country`, `class`, `subject`, `marks`, `sscmarks`, `username`, `password`, `otp`) VALUES
(1, 'raj', '1990-01-01', 'Female', '000000', 'aadityaa@juvale.com1', 'fytg', '656', 'maharastra', 'jhjhik', 'india', 'science', 'fyjc', '464', '898', 'raj', 'jar', 0),
(2, 'boy', '1998-05-04', 'Male', '1234567890', 'boy@com', 'ghatla', '71', 'maharastra', 'mumbai', 'india', 'vocationals', 'Computer SCIENCE', '72', '78', 'boy', 'boy1', 0),
(3, 'ganesh chavan', '2014-01-01', 'Male', '9765656', 'ganesh@chavan', 'parel', '6476', 'karanataka', 'mum', 'india', 'commerce', 'syjc', '56', '76', 'ganesh', 'chavan', 0),
(4, 'Shrutika', '1999-10-28', 'Female', '1234567810', 'shrutika@com', 'ghatla', '71', 'maharastra', 'mumbai', 'india', 'vocationals', 'Computer SCIENCE', '62', '78', 'shrutika', 'shrutika', 0),
(6, 'shruti', '1998-04-01', 'Female', '123456789', 'shruti@com', 'ghatla', '71', 'maharastra', 'mumbai', 'india', 'vocationals', 'Computer SCIENCE', '72', '79', 'shruti24', 'shruti24', 0),
(7, 'siddhi', '1999-03-04', 'Male', '98696987345', 'siddhi@com', 'ghatla village', '71', 'maharastra', 'mumbai', 'india', 'commerce', 'Accounts', '85', '79', 'SIDDHI', 'SIDDHI', 0),
(13, 'SHRUSH', '2017-11-01', 'Male', '1234567890', 'shrush@com', 'abcd', '66', 'maharastra', 'mum', 'india', 'science', 'Chemistry', '89', '79', 'SHRUSH', 'SHRUSH', 0),
(14, 'stud', '2019-01-03', 'Male', '123456780', 'stud1@gmail.com', 'stud', '71', 'goa', 'm', 'india', 'commerce', 'Accounts', '76', '89', 'stud1', 'stud', 524484),
(21, 'AADITYAA', '1995-01-02', 'Female', '1234567890', 'aadityaajuwale2000@gmail.com', 'vashi naka', '66', 'maharastra', 'mum', 'india', 'science', 'Sociology', '55', '76', 'AADITYAA', 'AADITYAA', 915872),
(22, 'SHRUTZ', '1995-04-01', 'Female', '1022030440', 'shrutikulaye24@gmail.com', 'CHEMBUR', '71', 'maharastra', 'MUMBAI', 'india', 'vocationals', 'Computer SCIENCE', '65', '76', 'SHRUTZ', 'SHRUTZ', 896673),
(23, 'RUTUJA', '1999-04-01', 'Female', '1234567890', 'shrutikulaye24@gmail.com', 'vile parle east', '71', 'maharastra', 'mum', 'india', 'ARTS', 'MATHS', '87', '71', 'RUTUJA', 'RUTUJA', 616906),
(24, 'SHUBHAM', '1999-05-01', 'Male', '0987654321', 'sammykulaye768@gmail.com', 'ghatla', '71', 'maharastra', 'mum', 'india', 'SCIENCE', 'PHYSICS', '68', '78', 'SAMMY', 'SAMMY', 520721),
(25, 'SAMMY', '1998-05-05', 'Male', '12345', 'ganeshchavan13999@gmail.com', 'parel', '71', 'maharastra', 'mum', 'india', 'VOCATIONAL SCIENCE', 'COMPUTER SCIENCE', '71', '80', 'SAM', 'SAM', 554174);

-- --------------------------------------------------------

--
-- Table structure for table `stud_login`
--

CREATE TABLE `stud_login` (
  `username` varchar(265) NOT NULL,
  `password` varchar(265) NOT NULL,
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stud_login`
--

INSERT INTO `stud_login` (`username`, `password`) VALUES
('AADITYAA', 'AADITYAA'),
('aadu', '1234'),
('boy', 'boy1'),
('bvbv', 'bvbv'),
('ganesh', 'chavan'),
('ganesh123', 'ganesh'),
('gauri', '12'),
('mansi', 'chembur'),
('ppp', 'ppp'),
('raj', 'jar'),
('RUTUJA', 'RUTUJA'),
('SAM', 'SAM'),
('SAMMY', 'SAMMY'),
('SHRUSH', 'SHRUSH'),
('shruti24', 'shruti24'),
('shrutika', 'shrutika'),
('SHRUTZ', 'SHRUTZ'),
('shu30', 'shu30'),
('SIDDHI', 'SIDDHI'),
('stud1', 'stud');
